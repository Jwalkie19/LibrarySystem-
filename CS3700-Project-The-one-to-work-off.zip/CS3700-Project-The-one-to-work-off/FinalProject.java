/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package MainFrame;

/**
 *
 * @author garre
 */
public class FinalProject {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
